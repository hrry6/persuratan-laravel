
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <span class="h1">
                    Dashboard
                </span>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <a href="surat/tambah">
                            <btn class="btn btn-success">Tambah </btn>
                        </a>

                    </div>
                    <p>
                        <hr>
                        <table class="table table-hover table-bordered DataTable">
                            <thead>
                                <tr>
                                    <th>Jenis Surat</th>
                                    <th>Pembuat</th>
                                    <th>Tanggal Surat</th>
                                    <th>Ringkasan</th>
                                    <th>File</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($r->jenis_surat); ?></td>
                                    <td><?php echo e($r->username); ?></td>
                                    <td><?php echo e($r->tanggal_surat); ?></td>
                                    <td><?php echo e($r->ringkasan); ?></td>
                                    <td>
                                        <?php if($r->file): ?>
                                            <img src="<?php echo e(url('foto') . '/' . $r->file); ?> "style="max-width: 250px; height: auto;" />
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="surat/edit/<?php echo e($r->id_surat); ?>"><btn class="btn btn-primary">EDIT</btn></a>
                                        <btn class="btn btn-danger btnHapus" idHapus="<?php echo e($r->id_surat); ?>">HAPUS</btn>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
            <div class="card-footer">

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="module">
    $('.DataTable tbody').on('click','.btnHapus',function(a){
        a.preventDefault();
        let idHapus = $(this).closest('.btnHapus').attr('idHapus');
        swal.fire({
            title : "Apakah anda ingin menghapus data ini?",
            showCancelButton: true,
            confirmButtonText: 'Setuju',
            cancelButtonText: `Batal`,
            confirmButtonColor: 'red'

        }).then((result)=>{
            if(result.isConfirmed){
                $.ajax({
                    type: 'DELETE',
                    url: 'surat/hapus',
                    data: {
                        id_surat : idHapus,
                        _token : "<?php echo e(csrf_token()); ?>"
                    },
                    success : function(data){
                        if(data.success){
                            swal.fire('Berhasil di hapus!', '', 'success').then(function(){
                                //Refresh Halaman
                                location.reload();
                            });
                        }
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tugasLaravel\persuratan_Harry\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>