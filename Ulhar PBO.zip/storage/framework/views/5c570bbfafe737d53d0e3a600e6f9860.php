<html>

<head>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss','resources/js/app.js']); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('header'); ?>

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        /* Show it is fixed to the top */
        body {
            min-height: 75rem;
            padding-top: 4.5rem;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Thunder Mail</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav me-auto mb-2 mb-md-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('dashboard/surat')); ?>">Dashboard</a>
                    </li>
                    <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('managemen-user/user')); ?>">Data User</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('jenis-surat/surat')); ?>">Data Jenis Surat</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('transaksi-surat')); ?>">Transaksi Surat</a>
                    </li>
                </ul>
                <form method="get" action="/logout">
                    <?php echo csrf_field(); ?>
                    <input type="submit" class="btn btn-danger" value="logout">
                </form>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php echo $__env->make('layout.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
<footer>
    <?php echo $__env->yieldContent('footer'); ?>
</footer>
<html><?php /**PATH C:\tugasLaravel\persuratan_Harry\resources\views/layout/layout.blade.php ENDPATH**/ ?>