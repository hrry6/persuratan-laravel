

<?php $__env->startSection('content'); ?>

<div class="row">
</div>
<div class="row">
    <div class="col-lg-12">
        <form method="POST" action="login">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input class="form-control" type="text" name="username" />
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input class="form-control" type="password" name="password" />
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
            </div>
            <div class="form-group">
                <input type="submit" value="login" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tugasLaravel\persuratan_Harry\resources\views/login/login.blade.php ENDPATH**/ ?>