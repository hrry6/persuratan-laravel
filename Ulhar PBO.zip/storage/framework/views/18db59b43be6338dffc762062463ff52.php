
<?php $__env->startSection('title','Managemen Jenis Surat'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <span class="h1">
                    Edit data Managemen Jenis Surat
                </span>
            </div>
            <div class="card-body">
                <form method="POST" action="/jenis-surat/surat/update" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                        <p>
                            <hr>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <input type="hidden" class="form-control" name="id_jenis_surat" value="<?php echo e($data->id_jenis_surat); ?>" />
                                <label>Jenis Surat</label>
                                <input type="text" class="form-control" name="jenis_surat" value="<?php echo e($data->jenis_surat); ?>" />
                            </div>
                            <?php echo csrf_field(); ?>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tugasLaravel\persuratan_Harry\resources\views/ManagemenJenisSurat/edit.blade.php ENDPATH**/ ?>