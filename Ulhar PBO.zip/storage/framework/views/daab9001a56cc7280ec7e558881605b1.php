
<?php $__env->startSection('title','Managemen User'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <span class="h1">
                    Edit data Managemen User
                </span>
            </div>
            <div class="card-body">
                <form method="POST" action="/managemen-user/user/update" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                        <p>
                            <hr>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <input type="hidden" class="form-control" name="id_user" value="<?php echo e($data->id_user); ?>" />
                                <label>Username</label>
                                <input type="text" class="form-control" name="username" value="<?php echo e($data->username); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="text" class="form-control" name="password" value="" />
                            </div>
                            <div class="form-group">
                                <label>Role</label>
                                <select class="form-select" name="role" aria-label="Default select example">
                                    <?php if($data->role == 'admin'): ?>
                                        <option selected value="admin">Admin</option>
                                    <?php else: ?>
                                        <option value="admin">Admin</option>
                                    <?php endif; ?>
                                    <?php if($data->role == 'operator'): ?>
                                        <option selected value="operator">Operator</option>
                                    <?php else: ?>
                                        <option value="operator">Operator</option>
                                    <?php endif; ?>
                                  </select>
                            </div>
                            <?php echo csrf_field(); ?>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tugasLaravel\persuratan_Harry\resources\views/ManagemenUser/edit.blade.php ENDPATH**/ ?>